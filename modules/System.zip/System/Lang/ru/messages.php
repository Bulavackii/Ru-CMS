<?php

return [
    'modules_management' => 'Управление модулями',
    'name' => 'Название',
    'version' => 'Версия',
    'active' => 'Активен',
    'yes' => 'Да',
    'no' => 'Нет',
];
