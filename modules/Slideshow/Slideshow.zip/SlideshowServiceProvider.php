<?php

namespace Modules\Slideshow;

use Illuminate\Support\ServiceProvider;

class SlideshowServiceProvider extends ServiceProvider
{
    /**
     * Регистрация сервисов модуля
     */
    public function register(): void
    {
        // Пока не требуется регистрация дополнительных сервисов или привязок
    }

    /**
     * Загрузка маршрутов, представлений и миграций модуля
     */
    public function boot(): void
    {
        // 📂 Подключение Blade-шаблонов с namespace 'Slideshow'
        $this->loadViewsFrom(__DIR__ . '/Views', 'Slideshow');

        // 🌐 Подключение маршрутов, если файл существует
        if (file_exists(__DIR__ . '/Routes/web.php')) {
            $this->loadRoutesFrom(__DIR__ . '/Routes/web.php');
        }

        // 🗃️ Подключение миграций базы данных
        $this->loadMigrationsFrom(__DIR__ . '/Database/Migrations');
    }
}
