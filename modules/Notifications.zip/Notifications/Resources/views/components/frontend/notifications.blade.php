@foreach ($notifications as $notification)
    <div class="bg-{{ $notification->color ?? 'blue' }}-100 text-{{ $notification->color ?? 'blue' }}-800 px-4 py-2 rounded mb-2">
        {!! $notification->message !!}
    </div>
@endforeach
