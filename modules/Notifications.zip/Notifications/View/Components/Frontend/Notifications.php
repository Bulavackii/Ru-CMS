<?php

namespace Modules\Notifications\View\Components\Frontend;

use Illuminate\View\Component;
use Modules\Notifications\Models\Notification;

class Notifications extends Component
{
    public $notifications;

    public function __construct()
    {
        $this->notifications = Notification::query()
            ->where('active', true)
            ->where(function ($q) {
                $q->whereNull('target_audience')
                  ->orWhere('target_audience', 'all');
            })
            ->get();
    }

    public function render()
    {
        return view('Notifications::components.frontend.notifications');
    }
}
