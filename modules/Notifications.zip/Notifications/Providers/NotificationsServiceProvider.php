<?php

namespace Modules\Notifications\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Blade;

class NotificationsServiceProvider extends ServiceProvider
{
    public function boot()
    {
        // 🔌 Роуты
        $this->loadRoutesFrom(__DIR__ . '/../Routes/web.php');

        // 🧩 Виды
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'Notifications');

        // 📦 Миграции
        $this->loadMigrationsFrom(__DIR__ . '/../Database/migrations');

        // 🧱 Компонент уведомлений
        Blade::component('frontend.notifications', \Modules\Notifications\View\Components\Frontend\Notifications::class);
    }

    public function register()
    {
        //
    }
}
