<?php

use Illuminate\Support\Facades\Route;
use Modules\Slideshow\Controllers\Admin\SlideshowController;

Route::prefix('admin')->middleware(['web', 'auth', 'admin'])->group(function () {
    Route::get('/slideshow', [SlideshowController::class, 'index'])->name('admin.slideshow.index');
    Route::get('/slideshow/create', [SlideshowController::class, 'create'])->name('admin.slideshow.create');
    Route::post('/slideshow', [SlideshowController::class, 'store'])->name('admin.slideshow.store');
    Route::get('/slideshow/{id}/edit', [SlideshowController::class, 'edit'])->name('admin.slideshow.edit');
    Route::put('/slideshow/{id}', [SlideshowController::class, 'update'])->name('admin.slideshow.update');
    Route::delete('/slideshow/{id}', [SlideshowController::class, 'destroy'])->name('admin.slideshow.destroy');

    Route::get('/slideshow/slide-template', [SlideshowController::class, 'slideTemplate'])->name('admin.slideshow.slide-template');
});
