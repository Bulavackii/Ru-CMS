@extends('layouts.admin')

@section('title', 'Создать слайдшоу')
@section('header', 'Создание слайдшоу')

@section('content')
    <form method="POST" action="{{ route('admin.slideshow.store') }}">
        @csrf
        <div class="mb-4">
            <label for="title" class="block font-semibold mb-1">Название слайдшоу</label>
            <input type="text" name="title" id="title" required value="{{ old('title') }}"
                   class="w-full border rounded px-3 py-2">
        </div>

        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            Сохранить
        </button>
    </form>

    <hr class="my-6">

    <h2 class="text-lg font-semibold mb-4">Слайды</h2>
    {{-- Пока слайдшоу не сохранено, слайдов нет --}}
    @include('Slideshow::admin.components.slides-list', ['slides' => []])
@endsection
