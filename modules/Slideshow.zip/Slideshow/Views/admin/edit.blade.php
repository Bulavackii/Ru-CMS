@extends('layouts.admin')

@section('title', 'Редактировать слайдшоу')
@section('header', 'Редактирование: ' . $slideshow->title)

@section('content')
<form action="{{ route('admin.slideshow.update', $slideshow) }}" method="POST">

        @csrf
        @method('PUT')

        <div class="mb-4">
            <label for="title" class="block font-semibold mb-1">Название слайдшоу</label>
            <input type="text" name="title" id="title" required value="{{ old('title', $slideshow->title) }}"
                   class="w-full border rounded px-3 py-2">
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Обновить
        </button>
    </form>

    <hr class="my-6">

    <h2 class="text-lg font-semibold mb-4">Слайды</h2>

    <a href="{{ route('admin.slides.create', ['slideshow_id' => $slideshow->id]) }}"
       class="mb-4 inline-block bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">
        ➕ Добавить слайд
    </a>

    @include('Slideshow::admin.components.slides-list', ['slides' => $slideshow->items])
@endsection
