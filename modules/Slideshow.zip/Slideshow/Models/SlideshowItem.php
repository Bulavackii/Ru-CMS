<?php

namespace Modules\Slideshow\Models;

use Illuminate\Database\Eloquent\Model;

class SlideshowItem extends Model
{
    protected $table = 'slideshow_items';

    protected $fillable = [
        'slideshow_id',
        'type',
        'file_path',
        'title',
        'description',
        'link',
        'sort_order',
    ];

    public function slideshow()
    {
        return $this->belongsTo(Slideshow::class);
    }

    public function getUrlAttribute()
    {
        return asset('storage/' . $this->file_path);
    }
}
