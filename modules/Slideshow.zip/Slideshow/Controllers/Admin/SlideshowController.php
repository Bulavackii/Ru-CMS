<?php

namespace Modules\Slideshow\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Modules\Slideshow\Models\Slideshow;

class SlideshowController extends Controller
{
    public function index()
    {
        $slideshows = Slideshow::withCount('media')->latest()->paginate(10);
        return view('Slideshow::admin.index', compact('slideshows'));
    }

    public function create()
    {
        return view('Slideshow::admin.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'media.*' => 'nullable|file|mimes:jpeg,png,webp,mp4,webm|max:20480',
        ]);

        $slug = $this->generateUniqueSlug($request->title);

        $slideshow = Slideshow::create([
            'title' => $request->title,
            'slug' => $slug,
            'description' => $request->description,
        ]);

        $this->handleMediaUpload($request, $slideshow);

        return redirect()->route('admin.slideshow.index')->with('success', 'Слайдшоу создано!');
    }

    public function edit(Slideshow $slideshow)
    {
        $slideshow->load('media');
        return view('Slideshow::admin.edit', compact('slideshow'));
    }

    public function update(Request $request, Slideshow $slideshow)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'media.*' => 'nullable|file|mimes:jpeg,png,webp,mp4,webm|max:20480',
        ]);

        $data = [
            'title' => $request->title,
            'description' => $request->description,
        ];

        // Обновляем slug, если заголовок изменился
        if ($slideshow->title !== $request->title) {
            $data['slug'] = $this->generateUniqueSlug($request->title);
        }

        $slideshow->update($data);

        $this->handleMediaUpload($request, $slideshow);

        return redirect()->route('admin.slideshow.index')->with('success', 'Слайдшоу обновлено!');
    }

    public function destroy(Slideshow $slideshow)
    {
        $slideshow->media->each(function ($item) {
            Storage::disk('public')->delete($item->file_path);
            $item->delete();
        });

        $slideshow->delete();

        return redirect()->route('admin.slideshow.index')->with('success', 'Слайдшоу удалено!');
    }

    public function slideTemplate()
    {
        return view('Slideshow::admin.components.slide-form');
    }

    /**
     * Обработка загрузки файлов.
     */
    private function handleMediaUpload(Request $request, Slideshow $slideshow): void
    {
        if ($request->hasFile('media')) {
            foreach ($request->file('media') as $file) {
                $path = $file->store('slideshows', 'public');
                $slideshow->media()->create([
                    'file_path' => $path,
                    'media_type' => str_contains($file->getMimeType(), 'video') ? 'video' : 'image',
                ]);
            }
        }
    }

    /**
     * Генерация уникального slug.
     */
    private function generateUniqueSlug(string $title): string
    {
        $slug = Str::slug($title);
        $originalSlug = $slug;
        $i = 1;

        while (Slideshow::where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $i++;
        }

        return $slug;
    }
}
